package com.example.myapplication;

import java.util.Vector;

public class SteelCastle extends Castle {

	public SteelCastle(String castleName, String suitableEnemy, Vector<Hero> vhero, Vector<Army> varmy) {
		super(castleName, suitableEnemy, vhero, varmy);
		this.boost=calculatepower(castleName, vhero,varmy);
	}

	@Override
	public double[] calculatepower(String castleName, Vector<Hero> vhero, Vector<Army> varmy) {
		double boost[]=new double[4] ,total[] = new double[4];
//		[0]= Infantry; [1] = Cavalry; [2] = Archer; [3] = Catapult
		
//		Calculate power from army
		for (int i = 0; i < varmy.size(); i++) {
			if (varmy.get(i).getArmytype().equalsIgnoreCase("infantry")) {
				boost[0]+=varmy.get(i).getTroops();
			} else if(varmy.get(i).getArmytype().equalsIgnoreCase("cavalry")){
				boost[1]+=varmy.get(i).getTroops();

			}else if (varmy.get(i).getArmytype().equalsIgnoreCase("Archer")) {
				boost[2]+=varmy.get(i).getTroops();
			}else {
				boost[3]+=varmy.get(i).getTroops();
			}
			total[0]= boost[0];
			total[1]=boost[1];
			total[2]= boost[2];
			total[3]= boost[3];
		}
//		Calculate power from hero
		for (int i = 0; i < vhero.size(); i++) {
			if (vhero.get(i).getHeroType().equalsIgnoreCase("infantry")) {
				boost[0]+=(vhero.get(i).getBoost()*total[0]);
			} else if(vhero.get(i).getHeroType().equalsIgnoreCase("cavalry")){
				boost[1]+=(vhero.get(i).getBoost()*total[1]);

			}else if(vhero.get(i).getHeroType().equalsIgnoreCase("Archer")){
				boost[2]+=(vhero.get(i).getBoost()*total[2]);

			}else if(vhero.get(i).getHeroType().equalsIgnoreCase("catapult")){
				boost[3]+=(vhero.get(i).getBoost()*total[3]);

			}
		}
//		Adding 20% skill from castle skin for boost[0] = Infantry
		boost[0]+=(0.20*total[0]);
		

		
		return boost;
	}

}
