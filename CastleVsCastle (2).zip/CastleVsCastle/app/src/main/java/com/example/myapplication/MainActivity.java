package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Random;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {
    Random ran = new Random();
    private void battle() {
        int gameplay=ran.nextInt(2);
        double[]doub = new double[4];
        int gameFlow=ran.nextInt(2);
        double attack,enemyattack;
        double baseSurvivor, enemySurvivor;
        Vector<Hero> vhbase = new Vector<Hero>();
        Vector<Hero>vhenemy = new Vector<Hero>();

        Vector<Army>varmybase = new Vector<Army>();
        Vector<Army>varmyenemy = new Vector<Army>();

        if (gameplay==1) {
            gameFlow = ran.nextInt(2);
            if (gameFlow==1) {
//			Cavalry - Archer
//			[0]= Infantry; [1] = Cavalry; [2] = Archer; [3] = Catapult
//			Adding troops to cavalry
                try {
                    Thread.sleep(1000);
                    vhbase.add(new Hero(0.40, "cavalry"));
                    vhbase.add(new Hero(0.40, "cavalry"));
                    vhbase.add(new Hero(0.40, "cavalry"));
                    vhbase.add(new Hero(0.40, "cavalry"));
                    vhbase.add(new Hero(0.40, "cavalry"));
                    varmybase.add(new Army("cavalry", 100000.00));
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
//			Adding troops to Archer
                try {
                    Thread.sleep(1000);
                    vhenemy.add(new Hero(0.40, "archer"));
                    vhenemy.add(new Hero(0.40, "archer"));
                    vhenemy.add(new Hero(0.40, "archer"));
                    vhenemy.add(new Hero(0.40, "archer"));
                    vhenemy.add(new Hero(0.40, "archer"));
                    varmyenemy.add(new Army("archer", 100000.00));
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
//				Base
                HorseCastle hc = new HorseCastle("Horse", "archer", vhbase, varmybase);

//				Enemy
                WoodCastle wc = new WoodCastle("Wood", "Cavalry", vhenemy, varmyenemy);


//			Battle starts here
                attack = hc.getBoost()[1]*0.1;

                enemySurvivor=100000-attack;


                enemyattack = wc.getBoost()[2]*0.4;

                baseSurvivor=100000-enemyattack;
                if(baseSurvivor<=0) {
                    baseSurvivor=0;
                }
                if (enemySurvivor<=0) {
                    enemySurvivor=0;
                }

                if (baseSurvivor<=enemySurvivor) {
                    Toast.makeText(getApplicationContext(), "Player 1 Lose With Army "+wc.getSuitableEnemy()+" and "+baseSurvivor+" survivors", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(),"Player 2 Win With Army "+hc.getSuitableEnemy()+" and "+enemySurvivor+" survivors",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Player 1 Win With Army "+wc.getSuitableEnemy()+" and "+baseSurvivor+" survivors", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(),"Player 2 Lose With Army "+hc.getSuitableEnemy()+" and "+enemySurvivor+" survivors",Toast.LENGTH_LONG).show();
                }


            }else {
//			Archer - Cavalry
//				[0]= Infantry; [1] = Cavalry; [2] = Archer; [3] = Catapult
//				Adding troops to cavalry
                try {
                    Thread.sleep(3000);
                    vhenemy.add(new Hero(0.40, "cavalry"));
                    vhenemy.add(new Hero(0.40, "cavalry"));
                    vhenemy.add(new Hero(0.40, "cavalry"));
                    vhenemy.add(new Hero(0.40, "cavalry"));
                    vhenemy.add(new Hero(0.40, "cavalry"));
                    varmyenemy.add(new Army("cavalry", 100000.00));
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
//				Adding troops to Archer
                try {
                    Thread.sleep(3000);
                    vhbase.add(new Hero(0.40, "archer"));
                    vhbase.add(new Hero(0.40, "archer"));
                    vhbase.add(new Hero(0.40, "archer"));
                    vhbase.add(new Hero(0.40, "archer"));
                    vhbase.add(new Hero(0.40, "archer"));
                    varmybase.add(new Army("archer", 100000.00));
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
//					Enemy
                HorseCastle hc = new HorseCastle("Horse", "archer", vhenemy, varmyenemy);
                System.out.println(hc.getBoost()[1]);
//					Base
                WoodCastle wc = new WoodCastle("Wood", "Cavalry", vhbase, varmybase);
                System.out.println(wc.getBoost()[2]);

//				Battle starts here
                attack = wc.getBoost()[2]*0.4;
                System.out.println(attack);
                enemySurvivor=100000-attack;
                System.out.println("Enemy Survivor "+enemySurvivor);

                enemyattack = hc.getBoost()[1]*0.1;
                System.out.println(enemyattack);
                baseSurvivor=100000-enemyattack;
                if(baseSurvivor<=0) {
                    baseSurvivor=0;
                }
                if (enemySurvivor<=0) {
                    enemySurvivor=0;
                }
                System.out.println("Base Survivor "+baseSurvivor);
                if (baseSurvivor<=enemySurvivor) {
                    Toast.makeText(getApplicationContext(), "Player 1 Lose With Army "+hc.getSuitableEnemy()+" and "+baseSurvivor+" survivors", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(),"Player 2 Win With Army "+wc.getSuitableEnemy()+" and "+enemySurvivor+" survivors",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Player 1 Win With Army "+hc.getSuitableEnemy()+" and "+baseSurvivor+" survivors", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(),"Player 2 Lose With Army "+wc.getSuitableEnemy()+" and "+enemySurvivor+" survivors",Toast.LENGTH_LONG).show();
                }

            }
        } else {
            gameFlow= ran.nextInt(2);
            if (gameFlow==1) {
//			Mix Armies - Infantry
                double powerCavalry,powerInfantry,powerArcher,powerCatapult;
//				Adding mix troops to castle Skin
                vhbase.add(new Hero(0.40, "infantry"));
                vhbase.add(new Hero(0.40, "cavalry"));
                vhbase.add(new Hero(0.40, "archer"));
                vhbase.add(new Hero(0.40, "catapult"));
                vhbase.add(new Hero(0.40,"catapult"));
                varmybase.add(new Army("infantry", 25000));
                varmybase.add(new Army("cavalry", 25000));
                varmybase.add(new Army("archer", 25000));
                varmybase.add(new Army("catapult", 25000));
//				Adding troops to enemy castle
                vhenemy.add(new Hero(0.40, "infantry"));
                vhenemy.add(new Hero(0.40, "infantry"));
                vhenemy.add(new Hero(0.40, "infantry"));
                vhenemy.add(new Hero(0.40, "infantry"));
                vhenemy.add(new Hero(0.40, "infantry"));
                varmyenemy.add(new Army("infantry", 100000));

                //base
                StoneCastle sc = new StoneCastle("Stone","infantry", vhbase, varmybase);

                //enemy
                SteelCastle sc1 = new SteelCastle("Steel", "Mix Armies", vhenemy, varmyenemy);

//				Battle starts here
//				adding power to army
                powerInfantry = sc.getBoost()[0]*1;
                powerCavalry=sc.getBoost()[1]*0.4;
                powerArcher=sc.getBoost()[2]*0.1;
                powerCatapult = sc.getBoost()[3]*0.2;

                enemySurvivor=100000-(powerInfantry+powerArcher+powerCatapult+powerCavalry);

                baseSurvivor=100000;
                if (sc.getBoost()[0]*1>=25000) {
                    baseSurvivor-=25000;
                }else {
                    baseSurvivor-=powerInfantry*1;
                }
                if (sc.getBoost()[1]*0.1>=25000) {
                    baseSurvivor-=25000;
                }else {
                    baseSurvivor-=sc.getBoost()[1]*0.1;
                }
                if (sc.getBoost()[2]*0.4>25000) {
                    baseSurvivor-=25000;
                } else {
                    baseSurvivor-=sc.getBoost()[2]*0.4;

                }
                if (sc.getBoost()[3]*0.2>25000) {
                    baseSurvivor-=25000;
                } else {
                    baseSurvivor-=sc.getBoost()[3]*0.2;
                }

                if (baseSurvivor<=enemySurvivor) {
                    Toast.makeText(getApplicationContext(), "Player 1 Lose With Army "+sc1.getSuitableEnemy()+" and "+baseSurvivor+" survivors", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(),"Player 2 Win With Army "+sc.getSuitableEnemy()+" and "+enemySurvivor+" survivors",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Player 1 Win With Army "+sc1.getSuitableEnemy()+" and "+baseSurvivor+" survivors", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(),"Player 2 Lose With Army "+sc.getSuitableEnemy()+" and "+enemySurvivor+" survivors",Toast.LENGTH_LONG).show();
                }
            } else {
                //			Infantry - Mix Armies
                double powerCavalry,powerInfantry,powerArcher,powerCatapult;
//				Adding mix troops to castle Skin
                vhbase.add(new Hero(0.40, "infantry"));
                vhbase.add(new Hero(0.40, "cavalry"));
                vhbase.add(new Hero(0.40, "archer"));
                vhbase.add(new Hero(0.40, "catapult"));
                vhbase.add(new Hero(0.40,"catapult"));
                varmybase.add(new Army("infantry", 25000));
                varmybase.add(new Army("cavalry", 25000));
                varmybase.add(new Army("archer", 25000));
                varmybase.add(new Army("catapult", 25000));
//				Adding troops to enemy castle
                vhenemy.add(new Hero(0.40, "infantry"));
                vhenemy.add(new Hero(0.40, "infantry"));
                vhenemy.add(new Hero(0.40, "infantry"));
                vhenemy.add(new Hero(0.40, "infantry"));
                vhenemy.add(new Hero(0.40, "infantry"));
                varmyenemy.add(new Army("infantry", 100000));

                //base
                StoneCastle sc = new StoneCastle("Stone","infantry", vhbase, varmybase);

                //enemy
                SteelCastle sc1 = new SteelCastle("Steel", "Mix Armies", vhenemy, varmyenemy);

//				Battle starts here
//				adding power to army
                powerInfantry = sc.getBoost()[0]*1;
                powerCavalry=sc.getBoost()[1]*0.4;
                powerArcher=sc.getBoost()[2]*0.1;
                powerCatapult = sc.getBoost()[3]*0.2;

                enemySurvivor=100000-(powerInfantry+powerArcher+powerCatapult+powerCavalry);

                baseSurvivor=100000;
                if (sc.getBoost()[0]*1>=25000) {
                    baseSurvivor-=25000;
                }else {
                    baseSurvivor-=powerInfantry*1;
                }
                if (sc.getBoost()[1]*0.1>=25000) {
                    baseSurvivor-=25000;
                }else {
                    baseSurvivor-=sc.getBoost()[1]*0.1;
                }
                if (sc.getBoost()[2]*0.4>25000) {
                    baseSurvivor-=25000;
                } else {
                    baseSurvivor-=sc.getBoost()[2]*0.4;

                }
                if (sc.getBoost()[3]*0.2>25000) {
                    baseSurvivor-=25000;
                } else {
                    baseSurvivor-=sc.getBoost()[3]*0.2;
                }
                System.out.println("Base "+baseSurvivor);
                System.out.println("Enemy "+enemySurvivor);
                if (baseSurvivor<=enemySurvivor) {
                    Toast.makeText(getApplicationContext(), "Player 1 Win With Army "+sc1.getSuitableEnemy()+" and "+baseSurvivor+" survivors", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(),"Player 2 Lose With Army "+sc.getSuitableEnemy()+" and "+enemySurvivor+" survivors",Toast.LENGTH_LONG).show();
                } else {

                    Toast.makeText(getApplicationContext(), "Player 1 Lose With Army "+sc1.getSuitableEnemy()+" and "+baseSurvivor+" survivors", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(),"Player 2 Win With Army "+sc.getSuitableEnemy()+" and "+enemySurvivor+" survivors",Toast.LENGTH_LONG).show();
                }

            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Battle battle = new Battle();
//                Thread th = new Thread(battle);
//                th.start();
                battle();

            }
        });
    }
}