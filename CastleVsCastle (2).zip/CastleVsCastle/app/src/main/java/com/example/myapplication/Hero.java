package com.example.myapplication;

public class Hero {
	double boost;
	String heroType;
	public double getBoost() {
		return boost;
	}
	public void setBoost(double boost) {
		this.boost = boost;
	}
	public String getHeroType() {
		return heroType;
	}
	public void setHeroType(String heroType) {
		this.heroType = heroType;
	}
	public Hero(double boost, String heroType) {
		super();
		this.boost = boost;
		this.heroType = heroType;
	}
	
}
