package com.example.myapplication;

public class Army {
private String armytype;
private double troops;
public String getArmytype() {
	return armytype;
}
public void setArmytype(String armytype) {
	this.armytype = armytype;
}
public double getTroops() {
	return troops;
}
public void setTroops(double troops) {
	this.troops = troops;
}
public Army(String armytype, double troops) {
	super();
	this.armytype = armytype;
	this.troops = troops;
}

}
