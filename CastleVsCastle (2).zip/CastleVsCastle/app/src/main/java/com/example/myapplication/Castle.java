package com.example.myapplication;

import java.util.Vector;

public abstract class Castle {
	 String castleName,suitableEnemy;
	double boost[];
	Vector<Hero>vhero;
	Vector<Army>varmy;
	public String getCastleName() {
		return castleName;
	}
	public void setCastleName(String castleName) {
		this.castleName = castleName;
	}
	public String getSuitableEnemy() {
		return suitableEnemy;
	}
	public void setSuitableTroop(String suitableTroop) {
		this.suitableEnemy = suitableTroop;
	}
	public double[] getBoost() {
		return boost;
	}
	public void setBoost(double[] boost) {
		this.boost = boost;
	}
	public abstract double[] calculatepower(String castleName, Vector<Hero>vhero, Vector<Army>varmy);
	public Castle(String castleName, String suitableEnemy, Vector<Hero>vhero,Vector<Army>varmy) {
		super();
		this.castleName = castleName;
		this.vhero=vhero;
		this.varmy=varmy;
		this.suitableEnemy= suitableEnemy;
	}
	public Vector<Hero> getVhero() {
		return vhero;
	}
	public void setVhero(Vector<Hero> vhero) {
		this.vhero = vhero;
	}
	
	
	

}
